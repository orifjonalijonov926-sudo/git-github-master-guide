# GitHub Guide — GitHub va Remote komandalar

## 1. GitHub nima?
**Ta’rif:** GitHub — Git repository’larini internetda saqlash, ulashish, ko‘rib chiqish va loyihalar ustida hamkorlik qilish platformasi.

**Vazifasi:** Loyihani onlayn saqlash, boshqalar bilan ulashish va masofadan ishlash uchun kerak.

**Amaliy misol:**
```bash
Brauzerda https://github.com/ saytiga kirib repository yaratish.
```

## 2. Git va GitHub farqi
**Ta’rif:** Git — versiya nazorati tizimi. GitHub — Git repository’larini internetda saqlash va boshqarish xizmati.

**Vazifasi:** Ularning farqini bilish lokal va internetdagi loyiha nusxasini to‘g‘ri boshqarishga yordam beradi.

**Amaliy misol:**
```bash
`git init` lokal repository yaratadi; `git push` commitlarni GitHub’ga yuboradi.
```

## 3. GitHub account nima?
**Ta’rif:** GitHub account — foydalanuvchining GitHub’dagi shaxsiy hisobidir.

**Vazifasi:** Repository yaratish, loyihalarni saqlash va platformadan foydalanish uchun kerak.

**Amaliy misol:**
```bash
GitHub’da ro‘yxatdan o‘tish va hisobga kirish.
```

## 4. Repository nima?
**Ta’rif:** GitHub repository — loyiha fayllari, commitlar, branchlar va loyiha ma’lumotlari saqlanadigan masofaviy ombor.

**Vazifasi:** Loyiha fayllarini onlayn saqlash va tarixini ko‘rish uchun ishlatiladi.

**Amaliy misol:**
```bash
GitHub’da New repository tugmasi orqali yangi repository yaratish.
```

## 5. Public va Private repository farqi
**Ta’rif:** Public repository hammaga ko‘rinadi. Private repository esa faqat egasi va ruxsat berilgan foydalanuvchilarga ko‘rinadi.

**Vazifasi:** Loyiha ochiq bo‘lishi yoki faqat tanlangan odamlar ko‘rishi kerakligini tanlashda ishlatiladi.

**Amaliy misol:**
```bash
Repository yaratishda Public yoki Private variantini tanlash.
```

## 6. Remote nima?
**Ta’rif:** Remote — lokal Git repository bilan bog‘langan masofaviy repository manzili. Ko‘pincha GitHub’dagi repository remote sifatida ulanadi.

**Vazifasi:** Lokal kompyuter va GitHub o‘rtasida ma’lumot almashish uchun kerak.

**Amaliy misol:**
```bash
`git remote -v` ulangan manzillarni ko‘rsatadi.
```

## 7. git remote add
**Ta’rif:** Mavjud lokal repository’ga remote manzil qo‘shadi. `origin` odatda asosiy remote nomi sifatida ishlatiladi.

**Vazifasi:** Lokal loyihani GitHub’dagi repository bilan bog‘lashda ishlatiladi.

**Amaliy misol:**
```bash
`git remote add origin https://github.com/USERNAME/REPOSITORY.git`
```

## 8. git remote -v
**Ta’rif:** Ulangan remote repository’larning fetch va push manzillarini ko‘rsatadi.

**Vazifasi:** Remote to‘g‘ri ulanganini tekshirishda ishlatiladi.

**Amaliy misol:**
```bash
`git remote -v`
```

## 9. git push
**Ta’rif:** Lokal commitlarni remote repository’ga yuboradi.

**Vazifasi:** Commitlarni GitHub’da ko‘rsatish va saqlash uchun ishlatiladi.

**Amaliy misol:**
```bash
`git push -u origin main`
```

## 10. git pull
**Ta’rif:** Remote repository’dagi yangilanishlarni olib keladi va joriy branchga birlashtiradi.

**Vazifasi:** GitHub’dagi yangi o‘zgarishlarni lokal kompyuterga olishda ishlatiladi.

**Amaliy misol:**
```bash
`git pull origin main`
```

## 11. git clone
**Ta’rif:** Masofaviy repository nusxasini kompyuterga yuklab, lokal Git repository yaratadi.

**Vazifasi:** Mavjud GitHub loyihasini kompyuterda ishlatishni boshlashda ishlatiladi.

**Amaliy misol:**
```bash
`git clone https://github.com/USERNAME/REPOSITORY.git`
```

## 12. GitHub’da branch nima?
**Ta’rif:** Branch — repository ichidagi alohida ish yo‘nalishi. U main branchni darhol o‘zgartirmasdan vazifa bajarishga yordam beradi.

**Vazifasi:** Yangi funksiya yoki hujjatni alohida tayyorlashda ishlatiladi.

**Amaliy misol:**
```bash
GitHub repository sahifasidagi branch ro‘yxatidan branchni tanlash.
```

## 13. GitHub’da commit nima?
**Ta’rif:** Commit — repository tarixidagi saqlangan o‘zgarishlar to‘plami. GitHub’da commit xabari va o‘zgarishlar tafsilotini ko‘rish mumkin.

**Vazifasi:** Qaysi o‘zgarishlar qachon kiritilganini tekshirish uchun ishlatiladi.

**Amaliy misol:**
```bash
`git commit -m "Update README"` va keyin `git push`.
```

## 14. GitHub’da faylni tahrirlash
**Ta’rif:** Repository ichida faylni ochib, Edit (qalam) tugmasi orqali matnni o‘zgartirish va Commit changes orqali saqlash mumkin.

**Vazifasi:** Kichik matnli tuzatishlarni brauzer orqali kiritishda ishlatiladi.

**Amaliy misol:**
```bash
Faylni ochish → Edit → matnni o‘zgartirish → Commit changes.
```

## 15. GitHub’da branchni o‘chirish
**Ta’rif:** Repository’ning Branches sahifasida branchni o‘chirish mumkin. Odatda ish merge qilingandan keyin o‘chiriladi.

**Vazifasi:** Keraksiz va tugallangan branchlarni tozalashda ishlatiladi.

**Amaliy misol:**
```bash
`git push origin --delete branch-name` — remote branchni o‘chiradi.
```

## GitHub’da yangi repository yaratish — 5 bosqich

1. https://github.com/ saytiga kiring va hisobingizga kiring.
2. `New` yoki `+` tugmasini bosib, `New repository` ni tanlang.
3. Repository nomini kiriting: `git-github-master-guide`.
4. `Public` yoki `Private` turini tanlang. Lokal README mavjud bo‘lsa, avtomatik README, `.gitignore` yoki license yaratish kataklarini belgilamang.
5. `Create repository` tugmasini bosing. Ko‘rsatilgan repository manzilini lokal loyihangizga remote sifatida ulang.

## GitHub bo‘yicha savol-javoblar

1. **GitHub nima?** — Git loyihalarini internetda saqlash va boshqarish platformasi.
2. **Public repository kimga ko‘rinadi?** — Internetdagi barcha foydalanuvchilarga.
3. **Private repository kimga ko‘rinadi?** — Egasi va ruxsat bergan foydalanuvchilarga.
4. **Remote nima?** — Lokal repository bog‘langan masofaviy manzil.
5. **`git push` nima qiladi?** — Lokal commitlarni remote’ga yuboradi.
6. **`git pull` nima qiladi?** — Remote’dagi o‘zgarishlarni olib kelib joriy branchga birlashtiradi.
