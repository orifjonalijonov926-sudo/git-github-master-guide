# Git & GitHub Master Guide

Bu loyiha Git, GitHub va Terminal komandalarini o‘rganish hamda amalda qo‘llash uchun yaratildi.

## Muallif
Ism Familiya

## Loyiha bo‘limlari
- [Git Guide](git-guide/git-commands.md)
- [GitHub Guide](github-guide/github-commands.md)
- [Terminal Guide](terminal-guide/terminal-commands.md)
- [Foydali havolalar](resources/useful-links.md)

## Maqsad
O‘rgangan komandalarimni amalda qo‘llash, ularning vazifasini tushunish va hujjatlashtirish.

## Branchlar
- `main` — loyiha boshlang‘ich fayllari
- `git-guide` — Git asoslari va komandalar
- `github-guide` — GitHub va remote komandalar
- `terminal-guide` — Terminal komandalar

> Eslatma: topshiriq davomida branchlar merge qilinmaydi. Har bir branch alohida GitHub’ga push qilinadi.
