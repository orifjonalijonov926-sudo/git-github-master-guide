# Git Guide — Git asoslari va Git komandalar

## 1. Git nima?
**Ta’rif:** Git — fayllardagi o‘zgarishlarni kuzatish va loyiha versiyalarini boshqarish uchun ishlatiladigan taqsimlangan versiya nazorati tizimi. U loyiha tarixini saqlaydi.

**Vazifasi:** Loyihada kim, qachon va qanday o‘zgarish qilganini bilish hamda oldingi holatga qaytish kerak bo‘lganda ishlatiladi.

**Amaliy misol:**
```bash
`git --version` — kompyuterda Git o‘rnatilganini va versiyasini tekshiradi.
```

## 2. Git nima uchun kerak?
**Ta’rif:** Git o‘zgarishlar tarixini saqlash, oldingi holatlarni ko‘rish, xatolarni aniqlash va branchlarda alohida ishlash uchun kerak.

**Vazifasi:** Dastur yoki hujjat ustida ishlaganda o‘zgarishlarni tartibli saqlash uchun foydalaniladi.

**Amaliy misol:**
```bash
`git status` — joriy o‘zgarishlar holatini ko‘rsatadi.
```

## 3. Repository nima?
**Ta’rif:** Repository — loyiha fayllari va ularning Git tarixini saqlaydigan joy. Lokal repository kompyuterda, remote repository esa GitHub kabi serverda bo‘lishi mumkin.

**Vazifasi:** Loyihani Git bilan kuzatishni boshlash va commitlar tarixini saqlash uchun kerak.

**Amaliy misol:**
```bash
`git init` — joriy papkada repository yaratadi.
```

## 4. Global va Local konfiguratsiya farqi
**Ta’rif:** Global sozlama foydalanuvchining barcha loyihalariga tatbiq etiladi. Local sozlama faqat joriy repository uchun amal qiladi. Local qiymat mavjud bo‘lsa, shu repository’da global qiymatdan ustun turadi.

**Vazifasi:** Muallif ismi va emailini Git commitlariga biriktirish uchun ishlatiladi.

**Amaliy misol:**
```bash
`git config --global user.name "Ism Familiya"` va `git config user.name "Ism Familiya"`.
```

## 5. git init
**Ta’rif:** Joriy papkada yangi Git repository boshlaydi.

**Vazifasi:** Yangi loyihani Git yordamida kuzatishni boshlashda ishlatiladi.

**Amaliy misol:**
```bash
`git init`
```

## 6. git status
**Ta’rif:** Repository holatini ko‘rsatadi: yangi, o‘zgargan, stagingga qo‘shilgan va commit qilinmagan fayllarni bildiradi.

**Vazifasi:** Qaysi fayllar o‘zgarganini commitdan oldin tekshirishda ishlatiladi.

**Amaliy misol:**
```bash
`git status`
```

## 7. git add
**Ta’rif:** Tanlangan fayllardagi o‘zgarishlarni staging area’ga qo‘shadi. Bu commitga kiritiladigan o‘zgarishlarni tanlash bosqichidir.

**Vazifasi:** Commitga qaysi fayllar kiritilishini belgilashda ishlatiladi.

**Amaliy misol:**
```bash
`git add README.md` yoki `git add .`
```

## 8. git commit
**Ta’rif:** Staging area’dagi o‘zgarishlarni repository tarixida yangi commit sifatida saqlaydi.

**Vazifasi:** Tayyor o‘zgarishlarni izoh bilan tarixga yozishda ishlatiladi.

**Amaliy misol:**
```bash
`git add .` so‘ng `git commit -m "Add project files"`.
```

## 9. git log
**Ta’rif:** Repository’dagi commitlar tarixini ko‘rsatadi. Muallif, sana va commit xabarlarini ko‘rish mumkin.

**Vazifasi:** Oldingi o‘zgarishlarni tekshirish va loyiha tarixini ko‘rishda ishlatiladi.

**Amaliy misol:**
```bash
`git log` yoki ixcham ko‘rinish uchun `git log --oneline`.
```

## 10. git branch
**Ta’rif:** Branchlarni ko‘rish, yangi branch yaratish va branchlarni boshqarish uchun ishlatiladi.

**Vazifasi:** Asosiy loyihaga ta’sir qilmasdan alohida vazifa ustida ishlash uchun yangi yo‘nalish yaratishda ishlatiladi.

**Amaliy misol:**
```bash
`git branch` — ro‘yxatni ko‘rsatadi; `git branch new-feature` — yangi branch yaratadi.
```

## 11. git switch
**Ta’rif:** Mavjud branchga o‘tadi. `-c` parametri yangi branch yaratib, unga bir vaqtda o‘tadi.

**Vazifasi:** Boshqa vazifa branchida ishlashni boshlashda ishlatiladi.

**Amaliy misol:**
```bash
`git switch main` yoki `git switch -c new-feature`.
```

## 12. git merge
**Ta’rif:** Boshqa branchdagi o‘zgarishlarni joriy branchga birlashtiradi.

**Vazifasi:** Alohida branchdagi ish tayyor bo‘lgach, uni asosiy branchga qo‘shishda ishlatiladi.

**Amaliy misol:**
```bash
`git switch main` so‘ng `git merge new-feature`.
```

## 13. git branch -d
**Ta’rif:** Lokal branchni o‘chiradi. Odatda birlashtirilgan branchni xavfsiz o‘chirish uchun ishlatiladi; merge qilinmagan ish bo‘lsa, Git ogohlantirishi mumkin.

**Vazifasi:** Ish tugab, branch kerak bo‘lmay qolganda ishlatiladi.

**Amaliy misol:**
```bash
`git switch main` so‘ng `git branch -d new-feature`.
```

## Git bo‘yicha savol-javoblar

1. **Git nima?** — Fayllar o‘zgarishi va loyiha versiyalarini kuzatuvchi tizim.
2. **Repository nima?** — Loyiha fayllari va Git tarixini saqlaydigan joy.
3. **`git init` nima qiladi?** — Joriy papkada Git repository yaratadi.
4. **`git add` va `git commit` farqi nima?** — `add` o‘zgarishlarni stagingga tayyorlaydi, `commit` esa ularni tarixga saqlaydi.
5. **Branch nima uchun kerak?** — Asosiy ishni o‘zgartirmasdan alohida vazifani bajarish uchun.
6. **`git status` nimani ko‘rsatadi?** — Repository’dagi fayllar holatini.
7. **`git log` nima uchun kerak?** — Commitlar tarixini ko‘rish uchun.
