# Terminal Guide — Terminal komandalar

## 1. Terminal nima?
**Ta’rif:** Terminal — kompyuter bilan matnli buyruqlar orqali muloqot qilish imkonini beradigan dastur yoki interfeys.

**Vazifasi:** Komandalar orqali papka va fayllarni boshqarish hamda dasturlarni ishga tushirishda ishlatiladi.

**Amaliy misol:**
```bash
Windows’da PowerShell yoki Git Bash dasturini ochish.
```

## 2. Terminal nima uchun kerak?
**Ta’rif:** Fayl va papkalarni boshqarish, dasturlarni ishga tushirish, Git buyruqlarini bajarish va tizim bilan tez ishlash uchun kerak.

**Vazifasi:** Grafik oynalar o‘rniga buyruqlar orqali tezkor ish bajarishda ishlatiladi.

**Amaliy misol:**
```bash
`pwd` va `ls` komandalarini bajarish.
```

## 3. pwd — joriy joylashuvni ko‘rish
**Ta’rif:** Joriy terminal qaysi papkada turganini to‘liq manzili bilan ko‘rsatadi.

**Vazifasi:** Kerakli papkada ekaningizni tekshirish uchun ishlatiladi.

**Amaliy misol:**
```bash
`pwd`
```

## 4. ls — fayllarni ko‘rish
**Ta’rif:** Joriy papkadagi fayl va papkalar ro‘yxatini ko‘rsatadi. Windows PowerShell’da `ls` alias sifatida ishlaydi.

**Vazifasi:** Papka ichidagi fayllarni ko‘rish uchun ishlatiladi.

**Amaliy misol:**
```bash
`ls`
```

## 5. cd — papkaga kirish
**Ta’rif:** Ko‘rsatilgan papkaga o‘tadi.

**Vazifasi:** Kerakli papkada ishlashni boshlash uchun ishlatiladi.

**Amaliy misol:**
```bash
`cd documents`
```

## 6. cd .. — yuqori papkaga chiqish
**Ta’rif:** Joriy papkaning bitta yuqori darajasiga qaytadi.

**Vazifasi:** Ichki papkadan ota papkaga chiqish uchun ishlatiladi.

**Amaliy misol:**
```bash
`cd ..`
```

## 7. mkdir — papka yaratish
**Ta’rif:** Yangi papka yaratadi.

**Vazifasi:** Loyiha fayllarini tartibli saqlash uchun papka ochishda ishlatiladi.

**Amaliy misol:**
```bash
`mkdir my-folder`
```

## 8. touch — fayl yaratish
**Ta’rif:** Git Bash, macOS va Linux’da yangi bo‘sh fayl yaratadi. PowerShell’da `New-Item` ishlatilishi mumkin.

**Vazifasi:** Yangi matn yoki loyiha faylini yaratishda ishlatiladi.

**Amaliy misol:**
```bash
Git Bash: `touch notes.txt`; PowerShell: `New-Item notes.txt -ItemType File`
```

## 9. cat — fayl mazmunini ko‘rish
**Ta’rif:** Matnli fayl ichidagi yozuvlarni terminalda chiqaradi.

**Vazifasi:** Faylni tahrirlovchi dasturda ochmasdan mazmunini ko‘rishda ishlatiladi.

**Amaliy misol:**
```bash
`cat notes.txt`
```

## 10. clear — terminalni tozalash
**Ta’rif:** Terminal oynasidagi avvalgi matnlarni ekrandan tozalaydi; fayllarni o‘chirmaydi.

**Vazifasi:** Terminal oynasini tartibli ko‘rinishga keltirish uchun ishlatiladi.

**Amaliy misol:**
```bash
`clear`
```

## 11. cp — nusxa olish
**Ta’rif:** Fayl yoki papkadan nusxa yaratadi.

**Vazifasi:** Asl faylni saqlab qolgan holda uning nusxasini olishda ishlatiladi.

**Amaliy misol:**
```bash
`cp notes.txt notes-copy.txt`
```

## 12. mv — ko‘chirish yoki nomini o‘zgartirish
**Ta’rif:** Fayl yoki papkani boshqa joyga ko‘chiradi yoki nomini o‘zgartiradi.

**Vazifasi:** Faylni kerakli joyga ko‘chirish yoki nomini almashtirishda ishlatiladi.

**Amaliy misol:**
```bash
`mv old.txt new.txt`
```

## 13. rm — fayl o‘chirish
**Ta’rif:** Ko‘rsatilgan faylni o‘chiradi.

**Vazifasi:** Faqat kerak emasligi aniq bo‘lgan sinov faylini o‘chirishda ishlatiladi.

**Amaliy misol:**
```bash
`rm notes-copy.txt`
```

## 14. git init — repository yaratish
**Ta’rif:** Joriy papkada yangi Git repository boshlaydi.

**Vazifasi:** Yangi loyiha papkasini Git bilan kuzatishni boshlashda ishlatiladi.

**Amaliy misol:**
```bash
`mkdir my-project` → `cd my-project` → `git init`
```

## 15. git status — Git holatini tekshirish
**Ta’rif:** Git repository’dagi yangi, o‘zgargan va stagingga qo‘shilgan fayllar holatini ko‘rsatadi.

**Vazifasi:** Commitdan oldin qanday o‘zgarishlar borligini tekshirishda ishlatiladi.

**Amaliy misol:**
```bash
`git status`
```

## Xavfsizlik eslatmasi

`rm` faylni o‘chiradi. Mashq paytida faqat o‘zingiz yaratgan sinov fayllarini o‘chiring. `rm -rf` kabi qaytarish qiyin bo‘lgan buyruqlarni ushbu topshiriqda ishlatmang.
