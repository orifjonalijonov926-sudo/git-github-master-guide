# Images

Topshiriqda `github.png` va `git.png` rasmlari ham ko‘rsatilgan. O‘zingizning GitHub repository va Git diagramma skrinshotlaringizni shu papkaga `github.png` va `git.png` nomlari bilan joylang.
