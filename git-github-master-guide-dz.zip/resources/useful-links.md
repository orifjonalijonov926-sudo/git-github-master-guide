# Foydali havolalar

1. [Git rasmiy sayti](https://git-scm.com/) — Git haqida ma’lumot va dasturni yuklab olish.
2. [Git hujjatlari](https://git-scm.com/doc) — Git komandalarining rasmiy qo‘llanmasi.
3. [GitHub](https://github.com/) — repository yaratish va loyihalarni saqlash platformasi.
4. [GitHub Docs](https://docs.github.com/) — GitHub’dan foydalanish bo‘yicha rasmiy qo‘llanma.
5. [GitHub Skills](https://skills.github.com/) — GitHub’ni amaliy mashqlar orqali o‘rganish.
